# CVPDL HW2 (R14944045): reproduce `test_pred.csv`

```bash
# environment: Python 3.10, CUDA GPU with bf16 (Ampere or newer); the versions used for the submitted run
pip install torch==2.13.0 torchvision==0.28.0 numpy==2.2.6 pandas==2.3.3 pillow==12.2.0 --extra-index-url https://download.pytorch.org/whl/cu129

# inputs next to code/: the Kaggle dataset in ./data (val/, test/) and ./source_resnet50_160.pth

# one online pass through the official harness -> out/test_pred.csv, out/test_run_log.json
cd code
python run.py --method mixtta_lfsq4 --split test --data ../data --ckpt ../source_resnet50_160.pth --out ../out --seed 0

# expected: sha256sum ../out/test_pred.csv = 48c04860a92e2eae3ff4b3858876df7bd22d365d25709718c1d490ffb0326dec (NVIDIA GeForce RTX 5090)
```
